import java.net.http.HttpClient.Builder;
import java.util.Random;

import akka.actor.typed.ActorSystem;
import akka.actor.typed.Behavior;
import akka.actor.typed.javadsl.AbstractBehavior;
import akka.actor.typed.javadsl.ActorContext;
import akka.actor.typed.javadsl.Behaviors;
import akka.actor.typed.javadsl.Receive;
import akka.actor.typed.javadsl.ReceiveBuilder;
import scala.sys.process.ProcessBuilderImpl.PipedBuilder;
public class Traders extends AbstractBehavior<Traders.StockMarket> {
	public static class StockMarket{
		String StockName;
		String Value;
		public StockMarket(String StockName,String Value) {
			// TODO Auto-generated constructor stub
			this.StockName = StockName;
			this.Value = Value;
		}
		public String GetStockName() {
			return StockName;
		}
		public double GetValue() {
			return (Double.parseDouble(Value));
		}
	}
	//String Message;
	///// Constracter ///////////
	public Traders(ActorContext<StockMarket> context){
		super(context);
	}
	public static Behavior<StockMarket> create(){
		return Behaviors.setup(context->new Traders(context));
	}
	////////////////////////////
	
	/////////////// reciving messages /////////////
	@Override
	public akka.actor.typed.javadsl.Receive<StockMarket> createReceive() {
		// TODO Auto-generated method stub
		return newReceiveBuilder()
				.onMessage(StockMarket.class,this::onMessage) //// String Message
				.build();
	}
	/////////////////////////////////////////////
	
	//////////////// what we should to do when reciving String Message /////////
	private Behavior<StockMarket> onMessage(StockMarket M){
		Random rand = new Random();
		boolean probability = rand.nextBoolean();
		Audit a = new Audit();
		if(probability) {
			// buy
			System.out.println("Buy Value:"+M.GetValue()+", StockName:"+M.GetStockName());
			a.WriteNewOpreation(M.GetStockName(), "Buy", M.GetValue());
		}
		else {
			// sell
			System.out.println("Sell Value:"+M.GetValue()+", StockName:"+M.GetStockName());
			a.WriteNewOpreation(M.GetStockName(), "Sell", M.GetValue());
		}
		return this;
	}
	////////////////////////////////////////////////////////////////////////////
}
