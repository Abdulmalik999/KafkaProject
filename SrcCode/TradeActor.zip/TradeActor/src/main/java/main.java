import java.util.ArrayList;
import java.util.Iterator;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import akka.Done;
import akka.kafka.*;
import com.typesafe.config.Config;
import akka.actor.typed.ActorSystem;
import akka.kafka.ConsumerSettings;
import akka.kafka.ProducerSettings;
public class main {

	public static void main(String[] args) {
		Consumer c1 = new Consumer("x", 0, "ConsumerGroup3");
		Consumer c2 = new Consumer("x", 1, "ConsumerGroup3");
		Consumer c3 = new Consumer("x", 2, "ConsumerGroup3");
		Consumer c4 = new Consumer("x", 3, "ConsumerGroup3");
		Consumer c5 = new Consumer("x", 4, "ConsumerGroup3");
		// TODO Auto-generated method stub
		ActorSystem<Traders.StockMarket> TreaderSystem = ActorSystem.create(Traders.create(),"TreaderActor");
		while(true){
			ArrayList<Traders.StockMarket> value =  c1.Consume();
			for(int i=0;i<value.size();i++) {
				TreaderSystem.tell(value.get(i));
			}
			value =  c2.Consume();
			for(int i=0;i<value.size();i++) {
				TreaderSystem.tell(value.get(i));
			}
			value =  c3.Consume();
			for(int i=0;i<value.size();i++) {
				TreaderSystem.tell(value.get(i));
			}
			value =  c4.Consume();
			for(int i=0;i<value.size();i++) {
				TreaderSystem.tell(value.get(i));
			}
			value =  c5.Consume();
			for(int i=0;i<value.size();i++) {
				TreaderSystem.tell(value.get(i));
			}
		}
	}

}
