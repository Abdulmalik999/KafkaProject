import org.apache.kafka.clients.consumer.ConsumerConfig;  
import org.apache.kafka.clients.consumer.ConsumerRecord;  
import org.apache.kafka.clients.consumer.ConsumerRecords;  
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.protocol.types.Field.Str;
import org.apache.kafka.common.serialization.StringDeserializer;  
import org.slf4j.Logger;  
import org.slf4j.LoggerFactory;

import scala.Enumeration.Val;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;  
import java.util.Collections;  
import java.util.Properties;  
  
public class Consumer {  
	String TopicName;
	int Partation;
	String GroupID;
	KafkaConsumer<String,String> consumer;
	public Properties ConfigConsumer(String grp_id) {
        String bootstrapServers="127.0.0.1:9092";   
        //Creating consumer properties  
        Properties properties=new Properties();  
        properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG,bootstrapServers);  
        properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG,   StringDeserializer.class.getName());  
        properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG,StringDeserializer.class.getName());  
        properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG,grp_id);  
        properties.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG,"earliest"); 
        return properties;
	}
	public Consumer(String TopicName,int Partation,String GroupID) {
		this.TopicName = TopicName;
		this.GroupID = GroupID;
		this.Partation = Partation;
        //creating consumer  
        consumer = new KafkaConsumer<String,String>(ConfigConsumer(GroupID));  
        //Assign  
        TopicPartition part = new TopicPartition(TopicName, Partation);
        consumer.assign(Arrays.asList(part));
	}
	public ArrayList<Traders.StockMarket> Consume() {
        //polling 
		ArrayList<Traders.StockMarket> Values = new ArrayList<Traders.StockMarket>();
        ConsumerRecords<String,String> records=consumer.poll(Duration.ofMillis(100));  
        for(ConsumerRecord<String,String> record: records){  
        	Values.add(new Traders.StockMarket(record.key(), record.value()));
        	//System.out.println("Key: "+ record.key() + ", Value:" +record.value());  
        	//System.out.println("Partition:" + record.partition()+",Offset:"+record.offset());  
        }
        return Values;
	}
}
