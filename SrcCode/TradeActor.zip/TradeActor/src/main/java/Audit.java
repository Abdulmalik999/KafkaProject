import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Audit {
	public boolean WriteNewOpreation(String StockName,String OpreationType,double price) {
		int type;
		switch(OpreationType) {
			case "Sell":
				type=0;
				break;
			case "Buy":
				type=1;
				break;
			default:
				return false;
		}
		 String myDriver = "com.mysql.cj.jdbc.Driver";
		 String myUrl = "jdbc:mysql://localhost/StockMarketProject?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
		 
		 try {
			Class.forName(myDriver);
			Connection conn = DriverManager.getConnection(myUrl, "root", "");
			  String sql = " insert into OpreationLog (StockName, type, price)" + " values (?, ?, ?)";
			  PreparedStatement preparedStmt = conn.prepareStatement(sql);
			  preparedStmt.setString (1, StockName);
			  preparedStmt.setInt (2, type);
			  preparedStmt.setDouble(3, price);
			  preparedStmt.execute();
			  conn.close();
			  return true;
		} catch (SQLException | ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
	}
}
