import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.util.*;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
public class Stocks {
	private String StockName;
	private int StockPrice;
	public void Stocks() {
		
	}
	public void GetStockPrice(String StockName) {
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("https://query1.finance.yahoo.com/v11/finance/quoteSummary/"+StockName+"?modules=financialData"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.build();
		try {
			HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			System.out.println(response.body());
		} catch (Exception e) {
			System.err.println(e);
		}
	}
	public double GetCryptoStockPrice(String StockName) {
		double price = 0;
		HttpRequest request = HttpRequest.newBuilder()
				.uri(URI.create("https://query2.finance.yahoo.com/v11/finance/quoteSummary/"+StockName+"?modules=Price"))
				.method("GET", HttpRequest.BodyPublishers.noBody())
				.build();
		try {
			HttpResponse<String> response = HttpClient.newHttpClient().send(request, HttpResponse.BodyHandlers.ofString());
			JSONParser parser = new JSONParser();
			JSONObject json = (JSONObject) parser.parse(response.body());
			json = (JSONObject) json.get("quoteSummary");
			json = (JSONObject)(((JSONArray)json.get("result")).get(0));
			json = (JSONObject) json.get("price");
			json = (JSONObject) json.get("regularMarketPrice");
			price = (double) json.get("raw");
			
		} catch (Exception e) {
			System.err.println(e);
		}
		return price;
	}
}
