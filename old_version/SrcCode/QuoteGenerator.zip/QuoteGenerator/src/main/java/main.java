
import akka.Done;

import akka.actor.ActorSystem;

import akka.kafka.*;

import akka.kafka.javadsl.Consumer;

import akka.kafka.javadsl.SendProducer;

import akka.stream.javadsl.Sink;

import akka.stream.javadsl.Source;

import com.typesafe.config.Config;

import org.apache.kafka.clients.consumer.ConsumerRecord;

import org.apache.kafka.clients.producer.*;

import org.apache.kafka.common.serialization.StringSerializer;

import java.util.ArrayList;
import java.util.Arrays;

import java.util.List;

import java.util.Map;

import java.util.Properties;

import java.util.concurrent.*;

public class main {
	
	public static void main(String[] args) {
		//////////// conect api ///////////
		/*
		Stocks s = new Stocks();
		s.GetCryptoStockPrice("BTC-USD");
		*/
		////////////////////////////////////
		
		////////////////////////// Create producer ///////////////////////
		String topic = "x";
		String ServerName = "localhost:9092";
		ActorSystem system = ActorSystem.create();
		Config config = system.settings().config().getConfig("akka.kafka.producer");
		ProducerSettings<String, String> producerSettings = ProducerSettings.create(config, new StringSerializer(), new StringSerializer()).withBootstrapServers(ServerName);
		org.apache.kafka.clients.producer.Producer<String, String> kafkaProducer = producerSettings.createKafkaProducer();
		kafkaProducer.close();
		////////////////////////////////////
		Stocks st = new Stocks();
		double S1 = 0,S2 = 0,S3 = 0,S4 = 0,S5 = 0;
		double NS1 = 0,NS2 = 0,NS3 = 0,NS4 = 0,NS5 = 0;
		Sender Sender1 = new Sender(topic, 0, system, producerSettings,"BTC-USD");
		Sender Sender2 = new Sender(topic, 1, system, producerSettings,"ETH-USD");
		Sender Sender3 = new Sender(topic, 2, system, producerSettings,"USDT-USD");
		Sender Sender4 = new Sender(topic, 3, system, producerSettings,"BNB-USD");
		Sender Sender5 = new Sender(topic, 4, system, producerSettings,"USDC-USD");
		////////////////////////////////////////
		while(true) {
			NS1 = st.GetCryptoStockPrice("BTC-USD");
			NS2 = st.GetCryptoStockPrice("ETH-USD");
			NS3 = st.GetCryptoStockPrice("USDT-USD");
			NS4 = st.GetCryptoStockPrice("BNB-USD");
			NS5 = st.GetCryptoStockPrice("USDC-USD");
			if(Double.compare(S1, NS1)!=0) {
				S1 = NS1;
				Sender1.send(S1);
			}
			if(Double.compare(S2, NS2)!=0) {
				S2 = NS2;
				Sender2.send(S2);
			}
			if(Double.compare(S3, NS3)!=0) {
				S3 = NS3;
				Sender3.send(S3);
			}
			if(Double.compare(S4, NS4)!=0) {
				S4 = NS4;
				Sender4.send(S4);
			}
			if(Double.compare(S5, NS5)!=0) {
				S5 = NS5;
				Sender5.send(S5);
			}
			// delay
			try {
				TimeUnit.SECONDS.sleep(20);
			} catch (Exception e) {
				System.err.println(e);
			}
		}
	}
}
